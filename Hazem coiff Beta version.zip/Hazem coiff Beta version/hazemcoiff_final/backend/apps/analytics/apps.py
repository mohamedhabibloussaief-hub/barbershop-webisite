"""
apps/analytics/apps.py
-----------------------
No models → no migrations needed for this app.
"""
from django.apps import AppConfig


class AnalyticsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name         = "apps.analytics"
    label        = "analytics"
    verbose_name = "Analytics"
