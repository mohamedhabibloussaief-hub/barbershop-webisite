"""
apps/appointments/serializers.py
---------------------------------
Four serializers, each with a single responsibility:

  AppointmentReadSerializer   — full representation for GET responses
  AppointmentCreateSerializer — validates + creates a booking atomically
  AppointmentCancelSerializer — validates + records a cancellation
  AppointmentStatusSerializer — barber/admin status transitions
"""

from datetime import timedelta

from django.db           import transaction
from django.utils        import timezone
from django.utils.translation import gettext_lazy as _
from rest_framework      import serializers

from apps.employees.models  import Employee
from apps.services.models   import Service
from apps.users.serializers import UserProfileSerializer
from apps.availability.service import slot_is_available
from .models import Appointment, Payment


# ─── Read ─────────────────────────────────────────────────────────────────────

class AppointmentReadSerializer(serializers.ModelSerializer):
    """
    Full appointment representation returned on all GET responses.
    Nested objects are read-only snapshots — never writeable through this serializer.
    """

    client        = UserProfileSerializer(read_only=True)
    employee_name = serializers.CharField(source="employee.user.full_name", read_only=True)
    employee_id   = serializers.UUIDField(source="employee.id", read_only=True)
    service_name  = serializers.CharField(source="service.name", read_only=True)
    service_id    = serializers.UUIDField(source="service.id", read_only=True)
    duration_minutes = serializers.IntegerField(source="service.duration_minutes", read_only=True)
    status_display   = serializers.CharField(source="get_status_display", read_only=True)

    # Payment snapshot — always present (created atomically with appointment).
    payment_status = serializers.CharField(
        source="payment.status", read_only=True, default="pending"
    )
    payment_amount = serializers.DecimalField(
        source="payment.amount", max_digits=8, decimal_places=2,
        read_only=True, default=None,
    )

    class Meta:
        model  = Appointment
        fields = (
            "id",
            "client", "employee_id", "employee_name",
            "service_id", "service_name", "duration_minutes",
            "start_time", "end_time",
            "status", "status_display",
            "cancelled_by_id", "cancellation_reason",
            "notes",
            "payment_status", "payment_amount",
            "created_at", "updated_at",
        )
        read_only_fields = fields


# ─── Create ───────────────────────────────────────────────────────────────────

class AppointmentCreateSerializer(serializers.Serializer):
    """
    Validates and creates a new appointment.

    Double-booking prevention:
      Uses SELECT FOR UPDATE inside an atomic transaction to lock the
      employee's appointment rows for the requested time window.
      If the slot is taken by the time the lock is acquired, raises 400.

    Payment creation:
      A Payment record is created atomically in the same transaction.
      Amount is copied from service.price at this moment — future price
      changes will not affect this booking's revenue figure.
    """

    employee_id = serializers.UUIDField()
    service_id  = serializers.UUIDField()
    start_time  = serializers.DateTimeField()
    notes       = serializers.CharField(required=False, default="", allow_blank=True)

    def validate_employee_id(self, value):
        try:
            employee = Employee.objects.get(pk=value, is_active=True)
        except Employee.DoesNotExist:
            raise serializers.ValidationError(_("Employee not found or inactive."))
        return employee

    def validate_service_id(self, value):
        try:
            service = Service.objects.get(pk=value, is_active=True)
        except Service.DoesNotExist:
            raise serializers.ValidationError(_("Service not found or inactive."))
        return service

    def validate(self, attrs):
        employee   = attrs["employee_id"]   # already resolved to Employee instance
        service    = attrs["service_id"]    # already resolved to Service instance
        start_time = attrs["start_time"]

        # Normalise to UTC-aware datetime.
        if timezone.is_naive(start_time):
            start_time = timezone.make_aware(start_time)
            attrs["start_time"] = start_time

        # Must not be in the past.
        if start_time < timezone.now():
            raise serializers.ValidationError(
                {"start_time": _("Cannot book a slot in the past.")}
            )

        end_time = start_time + timedelta(minutes=service.duration_minutes)
        attrs["end_time"] = end_time

        # Availability pre-check (without lock — fast rejection for obvious conflicts).
        if not slot_is_available(employee, start_time, service.duration_minutes):
            raise serializers.ValidationError(
                {"start_time": _("This slot is no longer available.")}
            )

        return attrs

    @transaction.atomic
    def create(self, validated_data):
        """
        Creates Appointment + Payment in a single atomic transaction.

        SELECT FOR UPDATE re-checks availability under a DB lock so two
        concurrent requests for the same slot cannot both succeed.
        """
        employee  = validated_data["employee_id"]
        service   = validated_data["service_id"]
        start     = validated_data["start_time"]
        end       = validated_data["end_time"]
        client    = self.context["request"].user

        # ── Lock & re-check ───────────────────────────────────────────────────
        # Lock all blocking appointments for this employee that touch our window.
        # Any concurrent transaction trying to book the same slot will block here
        # until we commit (or roll back).
        Appointment.objects.select_for_update().filter(
            employee   = employee,
            status__in = Appointment.BLOCKING_STATUSES,
            start_time__lt = end,
            end_time__gt   = start,
        )

        # Re-check under the lock — another request may have slipped in.
        if not slot_is_available(employee, start, service.duration_minutes):
            raise serializers.ValidationError(
                {"start_time": _("This slot was just booked. Please choose another.")}
            )

        # ── Create appointment ────────────────────────────────────────────────
        appointment = Appointment.objects.create(
            client    = client,
            employee  = employee,
            service   = service,
            start_time = start,
            end_time   = end,
            status    = Appointment.Status.PENDING,
            notes     = validated_data.get("notes", ""),
        )

        # ── Create payment snapshot ───────────────────────────────────────────
        # Amount locked to service price at time of booking.
        Payment.objects.create(
            appointment = appointment,
            amount      = service.price,
            status      = Payment.Status.PENDING,
        )

        return appointment

    def to_representation(self, instance):
        return AppointmentReadSerializer(instance, context=self.context).data


# ─── Cancel ───────────────────────────────────────────────────────────────────

class AppointmentCancelSerializer(serializers.Serializer):
    """
    Cancels an appointment.

    Rules:
      - Only pending or confirmed appointments can be cancelled.
      - Clients can only cancel their own appointments.
      - Barbers and admins can cancel any appointment.
      - cancelled_by is recorded for analytics.
    """

    cancellation_reason = serializers.CharField(
        required=False, default="", allow_blank=True, max_length=255
    )

    def validate(self, attrs):
        appointment = self.context["appointment"]
        user        = self.context["request"].user

        cancellable = [Appointment.Status.PENDING, Appointment.Status.CONFIRMED]
        if appointment.status not in cancellable:
            raise serializers.ValidationError(
                {"status": _(
                    f"Only pending or confirmed appointments can be cancelled. "
                    f"Current status: {appointment.get_status_display()}."
                )}
            )

        # Client can only cancel their own appointment.
        if user.is_client and appointment.client_id != user.pk:
            raise serializers.ValidationError(
                _("You can only cancel your own appointments.")
            )

        return attrs

    @transaction.atomic
    def save(self):
        appointment = self.context["appointment"]
        user        = self.context["request"].user

        appointment.status              = Appointment.Status.CANCELLED
        appointment.cancelled_by        = user
        appointment.cancellation_reason = self.validated_data.get("cancellation_reason", "")
        appointment.save(update_fields=[
            "status", "cancelled_by", "cancellation_reason", "updated_at"
        ])
        return appointment


# ─── Status update ────────────────────────────────────────────────────────────

# Valid transitions per actor.
# Key = current status, Value = statuses this actor may transition to.
BARBER_TRANSITIONS = {
    Appointment.Status.CONFIRMED : [Appointment.Status.ARRIVED],
    Appointment.Status.ARRIVED   : [Appointment.Status.COMPLETED, Appointment.Status.NO_SHOW],
}

ADMIN_TRANSITIONS = {
    Appointment.Status.PENDING   : [Appointment.Status.CONFIRMED, Appointment.Status.CANCELLED],
    Appointment.Status.CONFIRMED : [Appointment.Status.ARRIVED,   Appointment.Status.CANCELLED],
    Appointment.Status.ARRIVED   : [Appointment.Status.COMPLETED, Appointment.Status.NO_SHOW],
    Appointment.Status.NO_SHOW   : [Appointment.Status.CANCELLED],
}


class AppointmentStatusSerializer(serializers.Serializer):
    """
    Barber / admin status transitions.

    Enforces the status machine:
      Admin:  pending→confirmed, confirmed→arrived, arrived→completed|no_show
      Barber: confirmed→arrived, arrived→completed|no_show
    """

    status = serializers.ChoiceField(choices=Appointment.Status.choices)

    def validate_status(self, value):
        appointment = self.context["appointment"]
        user        = self.context["request"].user
        current     = appointment.status

        allowed_map  = ADMIN_TRANSITIONS if user.is_admin else BARBER_TRANSITIONS
        allowed_next = allowed_map.get(current, [])

        if value not in allowed_next:
            raise serializers.ValidationError(
                _(
                    f"Cannot transition from '{current}' to '{value}'. "
                    f"Allowed: {[s for s in allowed_next] or 'none'}."
                )
            )
        return value

    @transaction.atomic
    def save(self):
        appointment        = self.context["appointment"]
        appointment.status = self.validated_data["status"]
        appointment.save(update_fields=["status", "updated_at"])
        return appointment
