"""
apps/appointments/views.py
---------------------------
AppointmentViewSet handles all appointment operations.

Role-based queryset filtering:
  client  → only their own appointments
  barber  → only appointments assigned to them
  admin   → all appointments

Custom actions:
  POST /api/appointments/              → create (client only)
  GET  /api/appointments/              → list (role-filtered)
  GET  /api/appointments/<id>/         → retrieve
  POST /api/appointments/<id>/cancel/  → cancel (client owns it, or barber/admin)
  POST /api/appointments/<id>/status/  → status update (barber/admin only)
"""

import logging
from rest_framework             import status
from rest_framework.decorators  import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response    import Response
from rest_framework.viewsets    import GenericViewSet
from rest_framework.mixins      import CreateModelMixin, RetrieveModelMixin, ListModelMixin

from apps.users.permissions import IsAdmin, IsAdminOrBarber
from .models import Appointment
from .serializers import (
    AppointmentReadSerializer,
    AppointmentCreateSerializer,
    AppointmentCancelSerializer,
    AppointmentStatusSerializer,
)

logger = logging.getLogger("barbershop")


class AppointmentViewSet(
    CreateModelMixin,
    RetrieveModelMixin,
    ListModelMixin,
    GenericViewSet,
):
    """
    /api/appointments/
    /api/appointments/<uuid:pk>/
    /api/appointments/<uuid:pk>/cancel/
    /api/appointments/<uuid:pk>/status/

    Inherits only Create, Retrieve, and List — no Update or Destroy mixins.
    Modifications go through the named actions (cancel, status) which enforce
    the business rules and status machine.
    """

    permission_classes = [IsAuthenticated]

    # ── Queryset ──────────────────────────────────────────────────────────────
    def get_queryset(self):
        """
        Returns a queryset filtered by the requesting user's role.

        select_related loads client, employee→user, and service in a single
        JOIN query, preventing N+1 on the list endpoint.
        """
        user = self.request.user
        base = Appointment.objects.select_related(
            "client",
            "employee__user",
            "service",
            "payment",
        )

        if user.is_client:
            return base.filter(client=user)
        if user.is_barber:
            return base.filter(employee__user=user)
        # Admin sees everything.
        return base.all()

    # ── Serializer routing ────────────────────────────────────────────────────
    def get_serializer_class(self):
        if self.action == "create":
            return AppointmentCreateSerializer
        if self.action == "cancel":
            return AppointmentCancelSerializer
        if self.action == "status":
            return AppointmentStatusSerializer
        return AppointmentReadSerializer

    # ── Permission routing ────────────────────────────────────────────────────
    def get_permissions(self):
        if self.action == "status":
            return [IsAuthenticated(), IsAdminOrBarber()]
        return [IsAuthenticated()]

    # ── Create override ───────────────────────────────────────────────────────
    def create(self, request, *args, **kwargs):
        """
        Only clients can book. Barbers and admins create appointments through
        the admin portal (direct DB or admin interface for V1).
        """
        if not request.user.is_client:
            return Response(
                {"error": {"code": "forbidden", "message": "Only clients can book appointments."}},
                status=status.HTTP_403_FORBIDDEN,
            )

        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        appointment = serializer.save()

        logger.info(
            "Appointment created: client=%s employee=%s service=%s start=%s id=%s",
            appointment.client.email,
            appointment.employee,
            appointment.service.name,
            appointment.start_time,
            appointment.id,
        )

        return Response(
            {"data": AppointmentReadSerializer(appointment, context={"request": request}).data},
            status=status.HTTP_201_CREATED,
        )

    # ── List override ─────────────────────────────────────────────────────────
    def list(self, request, *args, **kwargs):
        """Wrap list results in a data envelope and support status filtering."""
        qs = self.get_queryset()

        # Optional ?status= filter for client portal ("upcoming" vs "past").
        status_filter = request.query_params.get("status")
        if status_filter:
            qs = qs.filter(status=status_filter)

        # Optional ?upcoming=true convenience filter.
        upcoming = request.query_params.get("upcoming")
        if upcoming and upcoming.lower() == "true":
            from django.utils import timezone
            qs = qs.filter(start_time__gte=timezone.now()).order_by("start_time")

        page = self.paginate_queryset(qs)
        if page is not None:
            serializer = AppointmentReadSerializer(page, many=True, context={"request": request})
            return self.get_paginated_response({"data": serializer.data})

        serializer = AppointmentReadSerializer(qs, many=True, context={"request": request})
        return Response({"data": serializer.data})

    # ── Retrieve override ─────────────────────────────────────────────────────
    def retrieve(self, request, *args, **kwargs):
        appointment = self.get_object()
        serializer  = AppointmentReadSerializer(appointment, context={"request": request})
        return Response({"data": serializer.data})

    # ── Custom action: cancel ─────────────────────────────────────────────────
    @action(detail=True, methods=["post"], url_path="cancel")
    def cancel(self, request, pk=None):
        """
        POST /api/appointments/<id>/cancel/

        Cancels a pending or confirmed appointment.
        Clients can only cancel their own. Barbers/admins can cancel any.
        """
        appointment = self.get_object()
        serializer  = AppointmentCancelSerializer(
            data    = request.data,
            context = {"request": request, "appointment": appointment},
        )
        serializer.is_valid(raise_exception=True)
        appointment = serializer.save()

        logger.info(
            "Appointment cancelled: id=%s by=%s reason='%s'",
            appointment.id,
            request.user.email,
            appointment.cancellation_reason,
        )

        return Response(
            {"data": AppointmentReadSerializer(appointment, context={"request": request}).data}
        )

    # ── Custom action: status update ──────────────────────────────────────────
    @action(detail=True, methods=["post"], url_path="status")
    def status(self, request, pk=None):
        """
        POST /api/appointments/<id>/status/
        { "status": "arrived" }

        Barbers and admins move appointments through the status machine.
        Invalid transitions are rejected with a descriptive 400.
        """
        appointment = self.get_object()
        serializer  = AppointmentStatusSerializer(
            data    = request.data,
            context = {"request": request, "appointment": appointment},
        )
        serializer.is_valid(raise_exception=True)
        appointment = serializer.save()

        logger.info(
            "Appointment status updated: id=%s new_status=%s by=%s",
            appointment.id,
            appointment.status,
            request.user.email,
        )

        return Response(
            {"data": AppointmentReadSerializer(appointment, context={"request": request}).data}
        )
