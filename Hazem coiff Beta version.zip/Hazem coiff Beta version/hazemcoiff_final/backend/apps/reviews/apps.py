"""
apps/reviews/apps.py
"""
from django.apps import AppConfig


class ReviewsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name         = "apps.reviews"
    label        = "reviews"
    verbose_name = "Reviews"
