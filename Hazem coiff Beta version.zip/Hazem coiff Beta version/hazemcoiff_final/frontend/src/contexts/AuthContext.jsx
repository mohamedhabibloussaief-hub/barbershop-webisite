/**
 * src/contexts/AuthContext.jsx
 * ----------------------------
 * Global authentication state for the entire app.
 *
 * Provides:
 *   user         — { id, email, full_name, role } | null
 *   isLoading    — true while checking auth on mount
 *   login(data)  — stores tokens, sets user, redirects by role
 *   logout()     — clears tokens, redirects to /login
 *
 * On mount: calls GET /auth/me/ with the in-memory token to rehydrate
 * the session after a React hot-reload. On a hard refresh the token is
 * gone (in-memory store cleared) so the user lands on /login as expected.
 *
 * Role → portal mapping:
 *   client  → /
 *   barber  → /employee/dashboard
 *   admin   → /admin/dashboard
 */

import { createContext, useContext, useState, useEffect, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import api, { tokenStore } from '../lib/axios'

const AuthContext = createContext(null)

// Role → default landing route
const ROLE_REDIRECT = {
  client: '/',
  barber: '/employee/dashboard',
  admin:  '/admin/dashboard',
}

export function AuthProvider({ children }) {
  const [user, setUser]           = useState(null)
  const [isLoading, setIsLoading] = useState(true)
  const navigate                  = useNavigate()

  // On mount: try to rehydrate from the in-memory token.
  useEffect(() => {
    const token = tokenStore.access
    if (!token) {
      setIsLoading(false)
      return
    }

    api.get('/auth/me/')
      .then(({ data }) => {
        setUser(data.data.user)
      })
      .catch(() => {
        tokenStore.clear()
      })
      .finally(() => {
        setIsLoading(false)
      })
  }, [])

  /**
   * Call after a successful login or register API response.
   * data = { user, access, refresh }
   */
  const login = useCallback((data) => {
    tokenStore.set(data.access, data.refresh)
    setUser(data.user)
    const redirect = ROLE_REDIRECT[data.user.role] ?? '/'
    navigate(redirect, { replace: true })
  }, [navigate])

  const logout = useCallback(async () => {
    // Blacklist the refresh token server-side (best-effort — don't block logout).
    try {
      if (tokenStore.refresh) {
        await api.post('/auth/logout/', { refresh: tokenStore.refresh })
      }
    } catch {
      // Ignore — still clear local state.
    }
    tokenStore.clear()
    setUser(null)
    navigate('/login', { replace: true })
  }, [navigate])

  const value = {
    user,
    isLoading,
    isAuthenticated: !!user,
    login,
    logout,
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
